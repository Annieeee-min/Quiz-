*Web/app English
- Sử dụng jQuery (thư viện JavaScript).
- Sử dụng bootstrap xây dựng giao diện một cách dễ dàng, tiện lợi.
- Sử dụng các animation bằng css làm sinh động cho web app.
- Triển khai đọc dữ liệu từ file json thay vì sử dụng server và kết nối database.
- Sử dụng mã hóa MD5 để hẹn chế tối đa việc bị lộ đáp án của các câu hỏi trong file json.