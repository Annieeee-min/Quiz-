# Tym-TQ

TỔNG HỢP CODE TRÁI TIM THỦ KHOA LÝ 

CODE được viết trên 2 ngôn ngữ HTML và PYTHON

Với HTML các bạn chỉ cần truy cập https://www.w3schools.com/tryit/ và Run.

Với PYTHON các bạn phải sử dụng Phần mềm đọc/viết mã code (Visual Studio, Notepad++, Python, Clion,...)
